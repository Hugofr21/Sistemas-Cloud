keytool -genkeypair -alias myserverkey -keyalg RSA -keysize 2048 -keystore keystore.p12 -validity 3650

package org.example.videocloud.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Service
public class VideoServices {

    @Value("${video.directory.path}")
    private String videoDirectoryPath;

    @Value("${video.base.url}")
    private String videoBaseUrl;


    public List<String> listAllVideo() {
        String projectDir = Paths.get("").toAbsolutePath().toString();
        List<String> listVideo = new ArrayList<>();
        File directory = new File(projectDir, videoDirectoryPath);
        File[] files = directory.listFiles();

        if (files != null && directory.isDirectory() && directory.exists()) {
            for (File file : files) {
                if (file.isFile()) {
                    String path = file.getAbsolutePath();
                    listVideo.add(path);
                }
            }
        }
        return listVideo;
    }

    public void saveVideo(MultipartFile file) throws IOException {
        String projectDir = Paths.get("").toAbsolutePath().toString();
        Path videoPath = Paths.get(projectDir, videoDirectoryPath, file.getOriginalFilename());

        Files.createDirectories(videoPath.getParent());
        file.transferTo(videoPath.toFile());
    }

    public String saveVideoAndGetUrl(MultipartFile file) throws IOException {
        String projectDir = Paths.get("").toAbsolutePath().toString();
        Path videoPath = Paths.get(projectDir, videoDirectoryPath, file.getOriginalFilename());

        Files.createDirectories(videoPath.getParent());
        file.transferTo(videoPath.toFile());

        String videoFileName = file.getOriginalFilename();
        String videoUrl = videoBaseUrl + "/" + videoFileName;
        return videoUrl;
    }

    public String getVideoDirectoryName() {
        return videoDirectoryPath;
    }
}
